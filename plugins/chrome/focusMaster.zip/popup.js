"use strict";

const UI = {
  badge: document.getElementById("status-badge"),
  errorContainer: document.getElementById("error-container"),
  errorMessage: document.getElementById("error-message"),
  mainToggle: document.getElementById("main-toggle"),
  ruleRadios: document.getElementsByName("siteRule"),
  profileSelect: document.getElementById("profile-select"),
  profileDesc: document.getElementById("profile-desc"),
  aggressiveSettings: document.getElementById("aggressive-settings"),
  optWorkerTimers: document.getElementById("opt-worker-timers"),
  optAudio: document.getElementById("opt-audio-keepalive"),
  realFocusStatus: document.getElementById("real-focus-status"),
  lastLostTime: document.getElementById("last-lost-time"),
  diagnosticsContent: document.getElementById("diagnostics-content"),
  btnReload: document.getElementById("btn-reload")
};

let currentTabId = null;
let isRestricted = false;

// ─── INITIALIZATION ────────────────────────────────────────────────────────────

async function init() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tabs || tabs.length === 0) throw new Error("No active tab found.");
    currentTabId = tabs[0].id;

    const status = await sendMessage({ type: "GET_STATUS", tabId: currentTabId });
    if (!status.ok) throw new Error(status.error?.message || "Failed to get status.");

    const settings = await sendMessage({ type: "GET_SETTINGS" });

    renderState(status, settings.settings);
    await loadDiagnostics();
    setupListeners();

  } catch (err) {
    showError(err.message);
    setMainBadge("Error", "error");
  }
}

// ─── RENDERING ─────────────────────────────────────────────────────────────────

function renderState(status, settings) {
  isRestricted = status.restricted;

  if (isRestricted) {
    setMainBadge("Unsupported Page", "error");
    UI.mainToggle.disabled = true;
    UI.mainToggle.checked = false;
    showError("Chrome prevents extensions from running on this page.");
    return;
  }

  UI.mainToggle.disabled = false;
  UI.mainToggle.checked = status.enabled;
  setMainBadge(status.enabled ? "Active" : "Inactive", status.enabled ? "active" : "");

  // Render Rule
  const rule = status.rule || "tab";
  for (const radio of UI.ruleRadios) {
    radio.checked = (radio.value === rule);
  }

  // Render Profile
  UI.profileSelect.value = settings.profile || "balanced";
  updateProfileDesc(settings.profile);

  // Render Aggressive Options
  UI.optWorkerTimers.checked = settings.workerTimers || false;
  UI.optAudio.checked = settings.audioKeepalive || false;
}

function updateProfileDesc(profile) {
  const descs = {
    visibility: "Spoofs visibility state only.",
    focus: "Spoofs visibility and focus. Blocks blur events.",
    balanced: "Recommended. Spoofs state and safely drops lifecycle events.",
    aggressive: "Heavy. Unthrottles timers and forces rendering."
  };
  UI.profileDesc.textContent = descs[profile] || "";
  if (profile === "aggressive") {
    UI.aggressiveSettings.classList.remove("hidden");
  } else {
    UI.aggressiveSettings.classList.add("hidden");
  }
}

async function loadDiagnostics() {
  if (isRestricted) {
    UI.realFocusStatus.textContent = "N/A";
    UI.lastLostTime.textContent = "N/A";
    return;
  }
  
  UI.diagnosticsContent.innerHTML = "<p>Loading...</p>";
  try {
    const res = await sendMessage({ type: "GET_DIAGNOSTICS", tabId: currentTabId });
    if (res.ok && res.diagnostics) {
      const d = res.diagnostics;
      let html = `<pre>${JSON.stringify(d, null, 2)}</pre>`;
      UI.diagnosticsContent.innerHTML = html;
      
      UI.realFocusStatus.textContent = d.realFocus === "focused" ? "Focused" : "Blurred";
      if (d.realFocus === "focused") {
        UI.realFocusStatus.style.color = "var(--success-color)";
      } else {
        UI.realFocusStatus.style.color = "var(--error-color)";
      }

      if (d.lastLostFocus) {
        const time = new Date(d.lastLostFocus);
        UI.lastLostTime.textContent = time.toLocaleTimeString();
      } else {
        UI.lastLostTime.textContent = "Never";
      }

      if (d.cleanup && d.cleanup.reloadRequired) {
        UI.btnReload.classList.remove("hidden");
        showError("A clean shutdown failed. Please reload the page.");
      }
    } else {
      UI.diagnosticsContent.innerHTML = "<p>Runtime not installed or page not ready.</p>";
      UI.realFocusStatus.textContent = "Unknown";
      UI.lastLostTime.textContent = "Unknown";
    }
  } catch (e) {
    UI.diagnosticsContent.innerHTML = `<p>Error: ${e.message}</p>`;
    UI.realFocusStatus.textContent = "Error";
    UI.lastLostTime.textContent = "Error";
  }
}

// ─── ACTIONS & LISTENERS ───────────────────────────────────────────────────────

function setupListeners() {
  UI.mainToggle.addEventListener("change", async (e) => {
    const enabled = e.target.checked;
    clearError();
    setMainBadge("Updating...", "");
    UI.mainToggle.disabled = true;

    try {
      const res = await sendMessage({ type: "SET_ENABLED", tabId: currentTabId, enabled });
      if (!res.ok) throw new Error(res.error?.message || "Failed to update state.");
      
      setMainBadge(enabled ? "Active" : "Inactive", enabled ? "active" : "");
    } catch (err) {
      showError(err.message);
      e.target.checked = !enabled; // Rollback
      setMainBadge(e.target.checked ? "Active" : "Inactive", e.target.checked ? "active" : "");
    } finally {
      UI.mainToggle.disabled = false;
      await loadDiagnostics();
    }
  });

  for (const radio of UI.ruleRadios) {
    radio.addEventListener("change", async (e) => {
      const val = e.target.value;
      try {
        if (val === "tab") {
          await sendMessage({ type: "REMOVE_SITE_RULE", tabId: currentTabId });
        } else {
          await sendMessage({ type: "SET_SITE_RULE", tabId: currentTabId, rule: val });
        }
        const status = await sendMessage({ type: "GET_STATUS", tabId: currentTabId });
        UI.mainToggle.checked = status.enabled;
        setMainBadge(status.enabled ? "Active" : "Inactive", status.enabled ? "active" : "");
        await loadDiagnostics();
      } catch (_err) {
        showError("Failed to update rule.");
      }
    });
  }

  UI.profileSelect.addEventListener("change", async (e) => {
    const profile = e.target.value;
    updateProfileDesc(profile);
    try {
      await sendMessage({ type: "SET_PROFILE", tabId: currentTabId, profile });
      await loadDiagnostics();
    } catch (err) {
      showError("Failed to update profile.");
    }
  });

  UI.btnReload.addEventListener("click", () => {
    chrome.tabs.reload(currentTabId);
    window.close();
  });
}

// ─── UTILS ─────────────────────────────────────────────────────────────────────

function sendMessage(msg) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(msg, (res) => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      resolve(res);
    });
  });
}

function setMainBadge(text, className) {
  UI.badge.textContent = text;
  UI.badge.className = className;
}

function showError(msg) {
  UI.errorMessage.textContent = msg;
  UI.errorContainer.classList.remove("hidden");
}

function clearError() {
  UI.errorContainer.classList.add("hidden");
  UI.errorMessage.textContent = "";
}

// Start
init();
