/**
 * FocusMaster — MAIN-world injection payload (Runtime)
 *
 * Implements a profile-driven, guarded, idempotent runtime for visibility and focus spoofing.
 */

(function () {
  "use strict";

  if (window.__focusMasterRuntime) {
    return; // Already injected
  }

  const runtime = {
    configure: configure,
    shutdown: shutdown,
    getDiagnostics: getDiagnostics,
  };

  window.__focusMasterRuntime = runtime;

  // ─── STATE & REFERENCES ────────────────────────────────────────────────────────

  let _config = null;
  let _isActive = false;

  // Original native references
  const _native = {
    setTimeout: window.setTimeout.bind(window),
    setInterval: window.setInterval.bind(window),
    clearTimeout: window.clearTimeout.bind(window),
    clearInterval: window.clearInterval.bind(window),
    requestAnimationFrame: window.requestAnimationFrame.bind(window),
    cancelAnimationFrame: window.cancelAnimationFrame.bind(window),
    addEventListener: EventTarget.prototype.addEventListener,
    getDesc: (obj, prop) => Object.getOwnPropertyDescriptor(obj, prop),
    docVisibilityState: Object.getOwnPropertyDescriptor(document, "visibilityState")?.get,
  };

  function findDescriptor(obj, prop) {
    let cur = obj;
    while (cur) {
      let d = Object.getOwnPropertyDescriptor(cur, prop);
      if (d) return d;
      cur = Object.getPrototypeOf(cur);
    }
    return null;
  }

  // Tracking for shutdown
  const _cleanup = {
    props: [], // { obj, prop, origDesc }
    eventListeners: [], // { target, type, listener, options }
    handlers: [], // { obj, prop, origDesc }
  };

  // Timers
  let _worker = null;
  let _workerBlobUrl = null;
  let _workerCallbacks = new Map();
  let _timerId = 1;
  const TIMER_OFFSET = 1e9;

  // rAF
  let _pendingRaf = new Map();
  let _nextRafId = 1;
  const RAF_OFFSET = 1e9;
  let _rafLoopTimer = null;

  // Audio
  let _audioCtx = null;
  let _audioGestureAttached = false;
  let _audioCheckTimer = null;

  // Real State
  let _reallyHidden = false;
  let _realFocus = true;
  let _lastLostFocus = null;

  // Diagnostics
  let _diagnostics = {
    audio: { requested: false, status: "disabled", lastError: null },
    worker: { requested: false, status: "disabled", lastError: null },
    raf: { enabled: false, fps: 0, pendingCallbacks: 0 },
    timers: { pageTimerOverrideEnabled: false, pendingTimeouts: 0, pendingIntervals: 0 },
    cleanup: { reloadRequired: false, failures: [] }
  };

  // ─── UTILS ─────────────────────────────────────────────────────────────────────

  function syncRealState() {
    try {
      if (_native.docVisibilityState) {
        _reallyHidden = _native.docVisibilityState.call(document) !== "visible";
      }
    } catch (_err) {
      /* ignore */
    }
  }

  function addOriginalListener(target, type, listener, options) {
    _native.addEventListener.call(target, type, listener, options);
    _cleanup.eventListeners.push({ target, type, listener, options });
  }

  function removeOriginalListener(target, type, listener, options) {
    try {
      target.removeEventListener(type, listener, options);
    } catch (_err) {
      /* ignore */
    }
  }

  // ─── CONFIGURATION ─────────────────────────────────────────────────────────────

  function configure(options) {
    if (!options || typeof options !== "object") return;

    const defaults = {
      profile: "balanced",
      spoofVisibility: true,
      spoofFocus: true,
      suppressLifecycleEvents: true,
      syntheticFocusIntervalMs: 0,
      workerTimers: false,
      audioKeepalive: false,
      rafFallbackFps: 10
    };

    _config = Object.assign({}, defaults, options);
    
    // Shut down existing mechanisms before applying new config
    if (_isActive) {
      shutdown(true); 
    }
    
    _isActive = true;
    syncRealState();

    if (_config.spoofVisibility) setupVisibilitySpoofing();
    if (_config.spoofFocus) setupFocusSpoofing();
    if (_config.suppressLifecycleEvents || _config.syntheticFocusIntervalMs > 0) setupEventHandling();
    
    setupWorker();
    
    if (_config.workerTimers) setupTimerOverrides();
    if (_config.rafFallbackFps > 0) setupRafFallback();
    if (_config.audioKeepalive) setupAudioKeepalive();

    // Listen for real state changes to drive rAF loop intelligently and track focus
    addOriginalListener(window, "visibilitychange", (e) => {
      if (e.isTrusted) syncRealState();
    }, true);

    addOriginalListener(window, "blur", (e) => {
      if (e.isTrusted) {
        _realFocus = false;
        _lastLostFocus = new Date().toISOString();
      }
    }, true);

    addOriginalListener(window, "focus", (e) => {
      if (e.isTrusted) {
        _realFocus = true;
      }
    }, true);
  }

  // ─── PROPERTY SPOOFING ─────────────────────────────────────────────────────────

  function overrideProperty(obj, prop, getterFn) {
    const origDesc = _native.getDesc(obj, prop) || findDescriptor(obj, prop);
    if (origDesc && origDesc.configurable === false) {
      _diagnostics.cleanup.failures.push(`Cannot configure ${prop}`);
      return;
    }
    _cleanup.props.push({ obj, prop, origDesc });
    Object.defineProperty(obj, prop, {
      configurable: true,
      enumerable: origDesc ? origDesc.enumerable : true,
      get: getterFn
    });
  }

  function setupVisibilitySpoofing() {
    overrideProperty(Document.prototype, "hidden", () => false);
    overrideProperty(Document.prototype, "visibilityState", () => "visible");
    overrideProperty(Document.prototype, "webkitHidden", () => false);
    overrideProperty(Document.prototype, "webkitVisibilityState", () => "visible");
  }

  function setupFocusSpoofing() {
    const origHasFocus = _native.getDesc(Document.prototype, "hasFocus") || findDescriptor(Document.prototype, "hasFocus");
    if (origHasFocus && origHasFocus.configurable === false) return;
    
    _cleanup.props.push({ obj: Document.prototype, prop: "hasFocus", origDesc: origHasFocus });
    Object.defineProperty(Document.prototype, "hasFocus", {
      configurable: true,
      enumerable: origHasFocus ? origHasFocus.enumerable : true,
      writable: origHasFocus ? origHasFocus.writable : true,
      value: function hasFocus() { return true; }
    });
  }

  // ─── EVENT HANDLING ────────────────────────────────────────────────────────────

  function setupEventHandling() {
    const blockedTypes = [];
    if (_config.suppressLifecycleEvents) {
      if (_config.profile === "aggressive" || _config.profile === "balanced") {
        blockedTypes.push("visibilitychange", "webkitvisibilitychange", "pagehide", "freeze");
        if (_config.spoofFocus) blockedTypes.push("blur", "focusout");
      }
    }

    if (blockedTypes.length > 0) {
      const origAddEventDesc = _native.getDesc(EventTarget.prototype, "addEventListener");
      if (!origAddEventDesc || origAddEventDesc.configurable !== false) {
        _cleanup.props.push({ obj: EventTarget.prototype, prop: "addEventListener", origDesc: origAddEventDesc });
        
        Object.defineProperty(EventTarget.prototype, "addEventListener", {
          configurable: true,
          enumerable: origAddEventDesc ? origAddEventDesc.enumerable : true,
          writable: origAddEventDesc ? origAddEventDesc.writable : true,
          value: function addEventListener(type, listener, options) {
            let shouldBlock = false;
            if (blockedTypes.indexOf(type) !== -1) {
              if (type === "blur" || type === "focusout") {
                 shouldBlock = (this === window); // Only block window blur
              } else {
                 shouldBlock = (this === document || this === window);
              }
            }
            if (shouldBlock) return;
            return _native.addEventListener.call(this, type, listener, options);
          }
        });
      }

      // Trap handlers (onblur, onvisibilitychange)
      const trapHandler = (obj, prop) => {
        const origDesc = _native.getDesc(obj, prop) || findDescriptor(obj, prop);
        if (origDesc && origDesc.configurable === false) return;
        _cleanup.handlers.push({ obj, prop, origDesc });
        
        let stored = null;
        Object.defineProperty(obj, prop, {
          configurable: true,
          enumerable: origDesc ? origDesc.enumerable : true,
          get: () => stored,
          set: (h) => { stored = typeof h === "function" ? h : null; }
        });
      };

      trapHandler(Document.prototype, "onvisibilitychange");
      trapHandler(window, "onvisibilitychange");
      if (_config.spoofFocus) trapHandler(window, "onblur");

      // Capture phase suppression
      const onSuppressedEvent = (e) => {
        if (e.isTrusted && (e.type === "visibilitychange" || e.type === "webkitvisibilitychange")) {
          syncRealState();
        }
        e.stopImmediatePropagation();
        e.preventDefault();
      };

      blockedTypes.forEach(type => {
        addOriginalListener(document, type, onSuppressedEvent, true);
        addOriginalListener(window, type, onSuppressedEvent, true);
      });
    }

    // Synthetic Focus
    if (_config.syntheticFocusIntervalMs > 0) {
       _workerCallbacks.set("synthFocus", {
         fn: () => {
           window.dispatchEvent(new Event("focus"));
           document.dispatchEvent(new Event("focus"));
         },
         once: false,
         interval: _config.syntheticFocusIntervalMs,
         last: performance.now()
       });
    }
  }

  // ─── WORKER & TIMERS ───────────────────────────────────────────────────────────

  function setupWorker() {
    _diagnostics.worker.requested = true;
    try {
      const workerSrc =
        "var t={};" +
        "onmessage=function(e){var d=e.data;" +
        "if(d.t==='st'){t[d.i]=setTimeout(function(){delete t[d.i];postMessage(d.i)},d.d)}" +
        "else if(d.t==='si'){t[d.i]=setInterval(function(){postMessage(d.i)},d.d)}" +
        "else if(d.t==='c'){clearTimeout(t[d.i]);clearInterval(t[d.i]);delete t[d.i]}};" +
        "setInterval(function(){postMessage(0)}, 100);"; // 100ms heartbeat
      
      const blob = new Blob([workerSrc], { type: "application/javascript" });
      _workerBlobUrl = URL.createObjectURL(blob);
      _worker = new Worker(_workerBlobUrl);
      
      _worker.onmessage = function (e) {
        const id = e.data;
        if (id === 0) {
           processInternalHeartbeat();
           return;
        }
        const entry = _workerCallbacks.get(id);
        if (!entry) return;
        if (entry.once) _workerCallbacks.delete(id);
        try { 
          if (typeof entry.fn === "function") {
             entry.fn.apply(undefined, entry.args); 
          }
        } catch (err) {
          _diagnostics.cleanup.failures.push("Timer callback error: " + err.message);
        }
      };
      _diagnostics.worker.status = "running";
    } catch (err) {
      _worker = null;
      _diagnostics.worker.status = "failed";
      _diagnostics.worker.lastError = err.message;
    }

    if (!_worker) {
      // Fallback heartbeat if worker fails (CSP)
      const fb = _native.setInterval(() => processInternalHeartbeat(), 100);
      _workerCallbacks.set("fb_heartbeat", fb);
    }
  }

  function processInternalHeartbeat() {
     const now = performance.now();
     // Process internal tasks like synthetic focus
     if (_config.syntheticFocusIntervalMs > 0) {
        const synth = _workerCallbacks.get("synthFocus");
        if (synth && (now - synth.last) >= synth.interval) {
           synth.last = now;
           synth.fn();
        }
     }
  }

  function setupTimerOverrides() {
    if (!_worker) return; // Cannot override if worker blocked
    _diagnostics.timers.pageTimerOverrideEnabled = true;

    window.setTimeout = function (fn, delay) {
      if (typeof fn !== "function") return _native.setTimeout.apply(window, arguments);
      const args = Array.prototype.slice.call(arguments, 2);
      const d = Math.max(0, Number(delay) || 0);
      const _id = _timerId++;
      _workerCallbacks.set(_id, { fn, args, once: true, isPage: true });
      _worker.postMessage({ t: "st", i: _id, d });
      return TIMER_OFFSET + _id;
    };

    window.setInterval = function (fn, delay) {
      if (typeof fn !== "function") return _native.setInterval.apply(window, arguments);
      const args = Array.prototype.slice.call(arguments, 2);
      const d = Math.max(0, Number(delay) || 0);
      const _id = _timerId++;
      _workerCallbacks.set(_id, { fn, args, once: false, isPage: true });
      _worker.postMessage({ t: "si", i: _id, d });
      return TIMER_OFFSET + _id;
    };

    window.clearTimeout = window.clearInterval = function (id) {
      if (typeof id === "number" && id >= TIMER_OFFSET) {
        const wid = id - TIMER_OFFSET;
        _workerCallbacks.delete(wid);
        if (_worker) _worker.postMessage({ t: "c", i: wid });
      } else if (id !== undefined) {
        _native.clearTimeout(id);
        _native.clearInterval(id);
      }
    };
  }

  // ─── rAF FALLBACK ──────────────────────────────────────────────────────────────

  function setupRafFallback() {
    _diagnostics.raf.enabled = true;
    _diagnostics.raf.fps = _config.rafFallbackFps;
    const intervalMs = 1000 / _config.rafFallbackFps;

    window.requestAnimationFrame = function (callback) {
      if (typeof callback !== "function") return _native.requestAnimationFrame(callback);
      const id = _nextRafId++;
      const entry = { cb: callback, done: false };
      
      entry.rafId = _native.requestAnimationFrame((ts) => {
        if (entry.done) return;
        entry.done = true;
        _pendingRaf.delete(id);
        callback(ts);
      });
      
      _pendingRaf.set(id, entry);
      ensureRafLoop(intervalMs);
      return RAF_OFFSET + id;
    };

    window.cancelAnimationFrame = function (id) {
      if (typeof id === "number" && id >= RAF_OFFSET) {
        const entry = _pendingRaf.get(id - RAF_OFFSET);
        if (entry) {
          entry.done = true;
          _native.cancelAnimationFrame(entry.rafId);
          _pendingRaf.delete(id - RAF_OFFSET);
        }
      } else {
        _native.cancelAnimationFrame(id);
      }
    };
  }

  function ensureRafLoop(intervalMs) {
    if (_rafLoopTimer !== null) return; // Loop running
    
    _rafLoopTimer = _native.setInterval(() => {
      syncRealState();
      if (!_reallyHidden) return; // Only process fallback if actually hidden
      
      if (_pendingRaf.size === 0) {
        _native.clearInterval(_rafLoopTimer);
        _rafLoopTimer = null;
        return;
      }

      const now = performance.now();
      const batch = Array.from(_pendingRaf.entries());
      _pendingRaf.clear(); // Clear before executing to allow requeue

      for (const [id, entry] of batch) {
        if (entry.done) continue;
        entry.done = true;
        _native.cancelAnimationFrame(entry.rafId);
        try {
          entry.cb(now);
        } catch (err) {
          // Native behavior preserves errors but doesn't crash the loop
          setTimeout(() => { throw err; }, 0);
        }
      }
    }, intervalMs);
  }

  // ─── AUDIO KEEPALIVE ───────────────────────────────────────────────────────────

  function setupAudioKeepalive() {
    _diagnostics.audio.requested = true;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) {
      _diagnostics.audio.status = "unsupported";
      _diagnostics.audio.lastError = "AudioContext not found";
      return;
    }

    _diagnostics.audio.status = "awaiting_gesture";

    const gestureKick = () => {
      if (_audioCtx) {
        if (_audioCtx.state !== "running") _audioCtx.resume().catch(()=>{});
        return;
      }
      
      try {
        _audioCtx = new AC();
        const osc = _audioCtx.createOscillator();
        const gain = _audioCtx.createGain();
        gain.gain.value = 0.00001;
        osc.connect(gain);
        gain.connect(_audioCtx.destination);
        osc.start();

        _diagnostics.audio.status = "running";
        
        _audioCheckTimer = _native.setInterval(() => {
           if (_audioCtx && _audioCtx.state !== "running") {
             _audioCtx.resume().catch(()=>{});
           }
        }, 3000);

        // Remove gesture listeners once started
        if (_audioGestureAttached) {
          ["click", "keydown", "touchstart"].forEach(evt => {
            removeOriginalListener(document, evt, gestureKick, { capture: true });
          });
          _audioGestureAttached = false;
        }
      } catch (err) {
        _diagnostics.audio.status = "failed";
        _diagnostics.audio.lastError = err.message;
      }
    };

    // Try immediately (works if autoplay policy allows)
    gestureKick();

    if (_diagnostics.audio.status === "awaiting_gesture") {
       _audioGestureAttached = true;
       ["click", "keydown", "touchstart"].forEach(evt => {
         addOriginalListener(document, evt, gestureKick, { capture: true });
       });
    }
  }

  // ─── SHUTDOWN & DIAGNOSTICS ────────────────────────────────────────────────────

  function shutdown(isReconfiguring = false) {
    if (!_isActive) return;

    try {
      // 1. Restore Properties
      _cleanup.props.forEach(({ obj, prop, origDesc }) => {
        try {
          if (origDesc) {
            Object.defineProperty(obj, prop, origDesc);
          } else {
            delete obj[prop];
          }
        } catch (_err) {
          _diagnostics.cleanup.failures.push(`Failed to restore ${prop}`);
          _diagnostics.cleanup.reloadRequired = true;
        }
      });
      _cleanup.props = [];

      // 2. Restore Handlers
      _cleanup.handlers.forEach(({ obj, prop, origDesc }) => {
        try {
          if (origDesc) Object.defineProperty(obj, prop, origDesc);
          else delete obj[prop];
        } catch (_err) {
          _diagnostics.cleanup.reloadRequired = true;
        }
      });
      _cleanup.handlers = [];

      // 3. Remove Event Listeners
      _cleanup.eventListeners.forEach(({ target, type, listener, options }) => {
        removeOriginalListener(target, type, listener, options);
      });
      _cleanup.eventListeners = [];

      // 4. Stop Timers
      if (_config.workerTimers) {
        window.setTimeout = _native.setTimeout;
        window.setInterval = _native.setInterval;
        window.clearTimeout = _native.clearTimeout;
        window.clearInterval = _native.clearInterval;
      }
      
      const fb_heartbeat = _workerCallbacks.get("fb_heartbeat");
      if (fb_heartbeat) _native.clearInterval(fb_heartbeat);
      _workerCallbacks.clear();

      if (_worker) {
        _worker.terminate();
        _worker = null;
      }
      if (_workerBlobUrl) {
        URL.revokeObjectURL(_workerBlobUrl);
        _workerBlobUrl = null;
      }

      // 5. Stop rAF Fallback
      if (_config.rafFallbackFps > 0) {
        window.requestAnimationFrame = _native.requestAnimationFrame;
        window.cancelAnimationFrame = _native.cancelAnimationFrame;
      }
      if (_rafLoopTimer !== null) {
        _native.clearInterval(_rafLoopTimer);
        _rafLoopTimer = null;
      }
      _pendingRaf.forEach((entry) => _native.cancelAnimationFrame(entry.rafId));
      _pendingRaf.clear();

      // 6. Stop Audio
      if (_audioCheckTimer) {
        _native.clearInterval(_audioCheckTimer);
        _audioCheckTimer = null;
      }
      if (_audioCtx) {
        try { _audioCtx.close(); } catch (_err) { /* ignore */ }
        _audioCtx = null;
      }

      _isActive = false;
      
      if (!isReconfiguring && !_diagnostics.cleanup.reloadRequired) {
        delete window.__focusMasterRuntime;
      }

    } catch (err) {
      _diagnostics.cleanup.failures.push("Shutdown exception: " + err.message);
      _diagnostics.cleanup.reloadRequired = true;
    }
  }

  function getDiagnostics() {
    _diagnostics.runtimeInstalled = true;
    _diagnostics.profile = _config ? _config.profile : "none";
    _diagnostics.realVisibility = _reallyHidden ? "hidden" : "visible";
    _diagnostics.realFocus = _realFocus ? "focused" : "blurred";
    _diagnostics.lastLostFocus = _lastLostFocus;
    
    let pageTimeouts = 0, pageIntervals = 0;
    _workerCallbacks.forEach(v => {
      if (v.isPage) {
        if (v.once) pageTimeouts++;
        else pageIntervals++;
      }
    });
    _diagnostics.timers.pendingTimeouts = pageTimeouts;
    _diagnostics.timers.pendingIntervals = pageIntervals;
    _diagnostics.raf.pendingCallbacks = _pendingRaf.size;

    return JSON.parse(JSON.stringify(_diagnostics)); // safe clone
  }

  // ─── INITIALIZATION LISTENER ───────────────────────────────────────────────────
  
  // Listen for the bridge event to configure or shutdown
  window.addEventListener("__FOCUSMASTER_CONFIG_INIT", function(e) {
    if (e.detail && e.detail.action === "shutdown") {
      shutdown();
    } else if (e.detail) {
      configure(e.detail);
    }
  });

})();