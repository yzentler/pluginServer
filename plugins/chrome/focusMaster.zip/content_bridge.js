/**
 * FocusMaster — Content Bridge (Isolated World)
 *
 * This script runs in the extension's isolated world. It is responsible for:
 * 1. Safely querying the background worker for this frame's configuration.
 * 2. Dispatching a secure CustomEvent to the MAIN world runtime (inject.js)
 *    to configure or shut down the spoofing logic.
 *
 * This prevents arbitrary page scripts from calling extension APIs or
 * reading extension state directly.
 */

(function () {
  "use strict";

  // Prevent multiple injections of the bridge in the same frame
  if (window.__focusMasterBridgeActive) return;
  window.__focusMasterBridgeActive = true;

  // We establish a random channel name that the MAIN world expects,
  // passed via a dataset attribute on the script tag, but since inject.js
  // is registered dynamically via chrome.scripting.registerContentScripts,
  // we can use a simpler approach: the MAIN world script listens on a known
  // event name, but validates the event source/type. Since only our isolated
  // script can fetch the actual config from the background, we pass it down.
  // To avoid malicious pages spoofing the config event, we use a unique token.

  // Actually, standard CustomEvent is sufficient if the data payload is
  // structured and the MAIN world validates it. The MAIN world is already
  // exposed to the page, so the page *could* trigger it, but the MAIN world
  // logic only activates if the config matches our schema.

  const CONFIG_EVENT_NAME = "__FOCUSMASTER_CONFIG_INIT";

  function sendConfigToMainWorld(config) {
    const evt = new CustomEvent(CONFIG_EVENT_NAME, {
      detail: config,
    });
    window.dispatchEvent(evt);
  }

  function fetchConfigAndInit() {
    try {
      chrome.runtime.sendMessage({ type: "GET_RUNTIME_CONFIG" }, (response) => {
        if (chrome.runtime.lastError) {
          console.warn("[FocusMaster Bridge] Error fetching config:", chrome.runtime.lastError.message);
          return;
        }

        if (response && response.ok) {
          sendConfigToMainWorld(response.config);
        } else {
          // If not enabled or error, we send a shutdown signal
          sendConfigToMainWorld({ action: "shutdown" });
        }
      });
    } catch (e) {
      console.warn("[FocusMaster Bridge] Communication failed:", e);
    }
  }

  // Listen for dynamic updates from the background script
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === "UPDATE_RUNTIME_CONFIG") {
      sendConfigToMainWorld(msg.config);
      sendResponse({ ok: true });
      return true;
    }
    if (msg.type === "SHUTDOWN_RUNTIME") {
      sendConfigToMainWorld({ action: "shutdown" });
      sendResponse({ ok: true });
      return true;
    }
    if (msg.type === "PING_BRIDGE") {
      sendResponse({ ok: true, bridgeActive: true });
      return true;
    }
  });

  // Fetch initial config on load
  fetchConfigAndInit();

})();
