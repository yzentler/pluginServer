# FocusMaster (v4.0.0)

A lightweight, highly configurable Chrome Extension that ensures web pages remain active and run at full speed even when the browser tab is hidden, occluded, or moved to a different macOS Space.

## What FocusMaster Does
Modern browsers (and operating systems like macOS) aggressively throttle background tabs to save battery and CPU. When you switch tabs or spaces, the browser may:
- Set `document.visibilityState` to `hidden`.
- Fire `visibilitychange`, `blur`, and `pagehide` events.
- Throttle `setTimeout` and `setInterval` to 1 execution per second (or 1 per minute).
- Stop executing `requestAnimationFrame` entirely.

FocusMaster combats this by injecting a guarded runtime that:
- Spoofs visibility and focus properties.
- Suppresses native lifecycle events to prevent the page from knowing it was hidden.
- Proxies timers through a Web Worker (which Chrome exempts from background throttling).
- Provides a silent AudioContext keepalive to mark the tab as "audible" (exempting it from intensive resource clamping).
- Polyfills `requestAnimationFrame` using a Web Worker heartbeat when the tab is genuinely hidden.

## Profiles

FocusMaster is built around **Profiles** to let you balance performance and resource usage.

- **Visibility Only (Light)**: Only spoofs `document.visibilityState` and `document.hidden`. No timers are touched.
- **Focus (Medium)**: Spoofs visibility and focus (`document.hasFocus()`). Suppresses `blur` events.
- **Balanced (Default)**: Safely drops lifecycle events (`visibilitychange`, `blur`, `pagehide`). Implements a 10 FPS `requestAnimationFrame` fallback.
- **Aggressive (Heavy)**: Unthrottles timers (worker-backed), enables optional silent audio keepalive, and forces higher FPS rendering. *Note: this will increase battery consumption.*

## Installation
1. Clone the repository.
2. Run `npm install` and `npm run build:icons` to generate the extension icons.
3. Open Chrome and navigate to `chrome://extensions`.
4. Enable "Developer mode" in the top right.
5. Click "Load unpacked" and select the `focusMaster` directory.

## Privacy & Security
- **No remote servers:** Everything runs locally.
- **No data collection:** The extension only reads the current URL origin to apply your specific site rules.
- **Host Permissions:** FocusMaster requires `<all_urls>` permission to utilize `chrome.scripting.registerContentScripts` at `document_start`. This is technically necessary to block `visibilitychange` events before the page's own scripts run. We do not inject our runtime unless you explicitly enable it for that tab or site.

## Diagnostics & Troubleshooting
Click the extension icon to open the popup. The **Diagnostics** section displays a structured JSON payload of the runtime's internal state (e.g., active timers, audio state, queued animation frames). 

If you disable FocusMaster on a complex page and a clean shutdown fails, the diagnostics panel will inform you that a **page reload is required** to restore native browser behavior safely.

## Supported Pages
FocusMaster injects securely into standard `http://` and `https://` pages. It **cannot** run on restricted pages such as:
- `chrome://` or `edge://` internal pages
- Chrome Web Store pages
- Extension pages

## Development
- **Lint:** `npm run lint`
- **Format:** `npm run format`
- **Test:** `npm run test:unit`
