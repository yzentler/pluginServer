// background.js

async function updateContextMenus() {
  const { enabledSites = [] } = await chrome.storage.sync.get('enabledSites');
  const { customAmount = 100 } = await chrome.storage.sync.get('customAmount');

  // Remove all existing menus
  chrome.contextMenus.removeAll(() => {
    if (enabledSites.length > 0) {
      // Create URL patterns from enabled hosts
      const patterns = enabledSites.map(host => {
        if (host === 'file://') return 'file:///*';
        return `*://${host}/*`;
      });
      
      try {
        chrome.contextMenus.create({
          id: 'click-custom',
          title: `Click ${customAmount} Times`,
          contexts: ['all'],
          documentUrlPatterns: patterns
        });
      } catch (e) {
        console.error('Failed to create context menus:', e);
      }
    }
  });
}

// Initialize on install or startup
chrome.runtime.onInstalled.addListener(updateContextMenus);
chrome.runtime.onStartup.addListener(updateContextMenus);

// Re-render when storage (settings) change
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'sync') {
    if (changes.enabledSites || changes.customAmount) {
      updateContextMenus();
    }
  }
});

// Handle clicks on context menus
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab || !tab.id) return;
  
  const { customAmount = 100 } = await chrome.storage.sync.get('customAmount');
  const count = parseInt(customAmount, 10);
  
  try {
    await chrome.tabs.sendMessage(tab.id, { action: 'multi-click', count });
  } catch (err) {
    // Inject the script dynamically if the tab wasn't refreshed after installation
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });
      // Short delay to allow script initialization
      setTimeout(async () => {
        await chrome.tabs.sendMessage(tab.id, { action: 'multi-click', count });
      }, 100);
    } catch (injectErr) {
      console.error('Could not inject content script:', injectErr);
    }
  }
});
