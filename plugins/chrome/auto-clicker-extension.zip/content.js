// content.js
let lastRightClickedElement = null;

// Listen for contextmenu events in the capture phase to ensure we catch it early
document.addEventListener('contextmenu', (event) => {
  lastRightClickedElement = event.target;
}, true);

// Listen for messages from background.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'multi-click' && lastRightClickedElement) {
    const times = message.count || 10;
    
    // Batch DOM updates if necessary, but dispatchEvent works synchronously on the target.
    // To prevent freezing the main thread on massive clicks (e.g., 1000), we can yield using requestAnimationFrame.
    
    (async () => {
      const BATCH_SIZE = 50;
      for (let i = 0; i < times; i += BATCH_SIZE) {
        await new Promise(r => requestAnimationFrame(() => {
          const limit = Math.min(i + BATCH_SIZE, times);
          for (let j = i; j < limit; j++) {
            lastRightClickedElement.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
            lastRightClickedElement.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
            lastRightClickedElement.click();
          }
          r();
        }));
        // yield to event loop
        await new Promise(r => setTimeout(r, 0));
      }
      sendResponse({ success: true });
    })();
    
    return true; // Keep channel open for async response
  }
});
