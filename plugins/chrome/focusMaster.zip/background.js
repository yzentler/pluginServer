/**
 * FocusMaster — Background Service Worker
 */

"use strict";

const DEFAULT_SETTINGS = {
  profile: "balanced",
  workerTimers: false,
  audioKeepalive: false,
  rafFallbackFps: 10,
  syntheticFocusIntervalMs: 0
};

// Internal Schema Version
const SCHEMA_VERSION = 1;

// Initialization
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install" || details.reason === "update") {
    chrome.storage.local.get(["schemaVersion", "settings", "siteRules"], (data) => {
      let updates = {};
      if (data.schemaVersion !== SCHEMA_VERSION) {
         updates.schemaVersion = SCHEMA_VERSION;
         if (!data.settings) updates.settings = DEFAULT_SETTINGS;
         if (!data.siteRules) updates.siteRules = {};
         chrome.storage.local.set(updates);
      }
    });
    
    // Register global scripts
    registerGlobalScripts();
  }
});

chrome.runtime.onStartup.addListener(() => {
  registerGlobalScripts();
});

// Dynamic Script Registration
// We inject everywhere permitted, but the scripts remain inert until the bridge
// verifies the tab/site is enabled.
async function registerGlobalScripts() {
  try {
    const scripts = await chrome.scripting.getRegisteredContentScripts({ ids: ["focusmaster-runtime", "focusmaster-bridge"] });
    if (scripts.length === 0) {
      await chrome.scripting.registerContentScripts([
        {
          id: "focusmaster-runtime",
          matches: ["<all_urls>"],
          js: ["inject.js"],
          world: "MAIN",
          runAt: "document_start",
          allFrames: true,
          matchOriginAsFallback: true
        },
        {
          id: "focusmaster-bridge",
          matches: ["<all_urls>"],
          js: ["content_bridge.js"],
          world: "ISOLATED",
          runAt: "document_start",
          allFrames: true,
          matchOriginAsFallback: true
        }
      ]);
    }
  } catch (e) {
    console.error("[FocusMaster] Failed to register global scripts:", e);
  }
}

// Restricted Page Detection
function isRestrictedUrl(url) {
  if (!url) return true;
  if (url.startsWith("chrome://")) return true;
  if (url.startsWith("chrome-extension://")) return true;
  if (url.startsWith("edge://")) return true;
  if (url.startsWith("about:")) return true;
  if (url.startsWith("devtools:")) return true;
  if (url.startsWith("view-source:")) return true;
  if (url.startsWith("https://chrome.google.com/webstore")) return true;
  if (url.startsWith("https://chromewebstore.google.com/")) return true;
  return false;
}

function getOrigin(url) {
  try {
    return new URL(url).origin;
  } catch {
    return null;
  }
}

// State Access
async function getSettings() {
  const data = await chrome.storage.local.get("settings");
  return data.settings || DEFAULT_SETTINGS;
}

async function getSiteRules() {
  const data = await chrome.storage.local.get("siteRules");
  return data.siteRules || {};
}

async function getTabSessionState(tabId) {
  if (!tabId || tabId < 0) return false;
  const data = await chrome.storage.session.get(`tab_${tabId}`);
  return data[`tab_${tabId}`] || false;
}

async function setTabSessionState(tabId, enabled) {
  if (!tabId || tabId < 0) return;
  await chrome.storage.session.set({ [`tab_${tabId}`]: enabled });
}

// Compute if a specific tab/url should be active
async function computeIsActive(tabId, url) {
  if (isRestrictedUrl(url)) return false;
  
  const origin = getOrigin(url);
  if (!origin) return false;

  const rules = await getSiteRules();
  const rule = rules[origin];

  if (rule === "never") return false;
  if (rule === "always") return true;

  // Otherwise, fallback to session tab state
  return await getTabSessionState(tabId);
}

function resolveConfig(settings) {
  const p = settings.profile;
  let c = {
    profile: p,
    spoofVisibility: true,
    spoofFocus: false,
    suppressLifecycleEvents: false,
    syntheticFocusIntervalMs: 0,
    workerTimers: false,
    audioKeepalive: false,
    rafFallbackFps: 0
  };

  if (p === "visibility") {
    c.spoofVisibility = true;
  } else if (p === "focus") {
    c.spoofVisibility = true;
    c.spoofFocus = true;
    c.suppressLifecycleEvents = true;
  } else if (p === "balanced") {
    c.spoofVisibility = true;
    c.spoofFocus = true;
    c.suppressLifecycleEvents = true;
    c.rafFallbackFps = 10;
  } else if (p === "aggressive") {
    c.spoofVisibility = true;
    c.spoofFocus = true;
    c.suppressLifecycleEvents = true;
    c.syntheticFocusIntervalMs = settings.syntheticFocusIntervalMs || 1000;
    c.workerTimers = settings.workerTimers || false;
    c.audioKeepalive = settings.audioKeepalive || false;
    c.rafFallbackFps = settings.rafFallbackFps || 30;
  }
  return c;
}

// Message Dispatcher
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== "object") return false;

  // Special internal query from the content bridge
  if (msg.type === "GET_RUNTIME_CONFIG") {
    handleGetRuntimeConfig(sender).then(sendResponse).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true; // async
  }

  // UI Handlers
  switch (msg.type) {
    case "GET_STATUS":
      handleGetStatus(msg).then(sendResponse);
      return true;
    case "SET_ENABLED":
      handleSetEnabled(msg).then(sendResponse);
      return true;
    case "SET_PROFILE":
      handleSetProfile(msg).then(sendResponse);
      return true;
    case "GET_DIAGNOSTICS":
      handleGetDiagnostics(msg).then(sendResponse);
      return true;
    case "SET_SITE_RULE":
      handleSetSiteRule(msg).then(sendResponse);
      return true;
    case "REMOVE_SITE_RULE":
      handleRemoveSiteRule(msg).then(sendResponse);
      return true;
    case "GET_SETTINGS":
      handleGetSettings(msg).then(sendResponse);
      return true;
    default:
      sendResponse({ ok: false, error: { code: "UNKNOWN_MESSAGE", message: "Unknown message type." }});
  }
});

async function handleGetRuntimeConfig(sender) {
  if (!sender.tab || !sender.tab.url) return { ok: false };
  const isActive = await computeIsActive(sender.tab.id, sender.tab.url);
  if (!isActive) return { ok: false };

  const settings = await getSettings();
  const config = resolveConfig(settings);
  updateBadge(sender.tab.id, true, config);
  return { ok: true, config };
}

async function handleGetStatus(msg) {
  if (!msg.tabId) return { ok: false, error: { code: "BAD_ARGS", message: "Missing tabId" }};
  const tab = await chrome.tabs.get(msg.tabId);
  const restricted = isRestrictedUrl(tab.url);
  
  const origin = getOrigin(tab.url);
  const rules = await getSiteRules();
  const rule = origin ? rules[origin] : null;
  
  const enabled = await computeIsActive(msg.tabId, tab.url);
  const settings = await getSettings();

  return { ok: true, enabled, restricted, rule, profile: settings.profile };
}

async function handleSetEnabled(msg) {
  if (!msg.tabId) return { ok: false, error: { code: "BAD_ARGS", message: "Missing tabId" }};
  
  const tab = await chrome.tabs.get(msg.tabId);
  if (isRestrictedUrl(tab.url)) {
    return { ok: false, error: { code: "UNSUPPORTED_URL", message: "Cannot enable on restricted pages." }};
  }

  updateBadge(msg.tabId, "...", null);

  await setTabSessionState(msg.tabId, msg.enabled);
  const settings = await getSettings();
  const config = resolveConfig(settings);

  try {
    if (msg.enabled) {
      await chrome.tabs.sendMessage(msg.tabId, { type: "UPDATE_RUNTIME_CONFIG", config });
      updateBadge(msg.tabId, true, config);
    } else {
      await chrome.tabs.sendMessage(msg.tabId, { type: "SHUTDOWN_RUNTIME" });
      updateBadge(msg.tabId, false, null);
    }
  } catch (err) {
    // Communication failed — maybe frame not loaded. We can try executeScript to bootstrap if turning ON.
    if (msg.enabled) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: msg.tabId, allFrames: true },
          files: ["inject.js"],
          world: "MAIN"
        });
        await chrome.scripting.executeScript({
          target: { tabId: msg.tabId, allFrames: true },
          files: ["content_bridge.js"],
          world: "ISOLATED"
        });
        updateBadge(msg.tabId, true, config);
      } catch (e) {
        updateBadge(msg.tabId, "X", null);
        return { ok: false, error: { code: "INJECT_FAILED", message: "Injection failed: " + e.message }};
      }
    } else {
      // Failed to shut down gracefully
      updateBadge(msg.tabId, "X", null);
      return { ok: false, error: { code: "SHUTDOWN_FAILED", message: "Failed to communicate with tab." }};
    }
  }
  
  return { ok: true, enabled: msg.enabled };
}

async function handleSetProfile(msg) {
  const settings = await getSettings();
  settings.profile = msg.profile;
  await chrome.storage.local.set({ settings });

  // Broadcast to all active tabs
  broadcastConfigUpdate(settings);
  return { ok: true, profile: settings.profile };
}

async function handleGetSettings(_msg) {
  const settings = await getSettings();
  return { ok: true, settings };
}

async function handleSetSiteRule(msg) {
  if (!msg.tabId || !msg.rule) return { ok: false };
  const tab = await chrome.tabs.get(msg.tabId);
  const origin = getOrigin(tab.url);
  if (!origin) return { ok: false };

  const rules = await getSiteRules();
  rules[origin] = msg.rule;
  await chrome.storage.local.set({ siteRules: rules });

  // If rule changed, re-evaluate tab state
  const enabled = await computeIsActive(msg.tabId, tab.url);
  handleSetEnabled({ type: "SET_ENABLED", tabId: msg.tabId, enabled });
  
  return { ok: true, rule: msg.rule };
}

async function handleRemoveSiteRule(msg) {
  if (!msg.tabId) return { ok: false };
  const tab = await chrome.tabs.get(msg.tabId);
  const origin = getOrigin(tab.url);
  if (!origin) return { ok: false };

  const rules = await getSiteRules();
  delete rules[origin];
  await chrome.storage.local.set({ siteRules: rules });

  const enabled = await computeIsActive(msg.tabId, tab.url);
  handleSetEnabled({ type: "SET_ENABLED", tabId: msg.tabId, enabled });

  return { ok: true };
}

async function handleGetDiagnostics(msg) {
  if (!msg.tabId) return { ok: false };
  
  try {
    const responses = await chrome.scripting.executeScript({
      target: { tabId: msg.tabId },
      func: () => {
         if (window.__focusMasterRuntime) return window.__focusMasterRuntime.getDiagnostics();
         return null;
      },
      world: "MAIN"
    });
    
    if (responses && responses[0] && responses[0].result) {
      return { ok: true, diagnostics: responses[0].result };
    }
    return { ok: true, diagnostics: null };
  } catch (err) {
    return { ok: false, error: { code: "DIAGNOSTICS_FAILED", message: err.message }};
  }
}

async function broadcastConfigUpdate(settings) {
  const config = resolveConfig(settings);
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (isRestrictedUrl(tab.url)) continue;
    const isActive = await computeIsActive(tab.id, tab.url);
    if (isActive) {
      try {
        await chrome.tabs.sendMessage(tab.id, { type: "UPDATE_RUNTIME_CONFIG", config });
        updateBadge(tab.id, true, config);
      } catch (_err) { /* ignore */ }
    }
  }
}

function updateBadge(tabId, state, config) {
  if (state === false) {
    chrome.action.setBadgeText({ text: "", tabId });
    chrome.action.setTitle({ title: "FocusMaster: Disabled", tabId });
    chrome.action.setIcon({ path: "icons/icon-off-32.png", tabId });
  } else if (state === "...") {
    chrome.action.setBadgeText({ text: "...", tabId });
    chrome.action.setBadgeBackgroundColor({ color: "#2196F3", tabId });
  } else if (state === "X") {
    chrome.action.setBadgeText({ text: "X", tabId });
    chrome.action.setBadgeBackgroundColor({ color: "#f44336", tabId });
    chrome.action.setTitle({ title: "FocusMaster: Error", tabId });
    chrome.action.setIcon({ path: "icons/icon-error-32.png", tabId });
  } else if (state === true && config) {
    let text = "ON";
    let color = "#00e676";
    let icon = "icons/icon-on-32.png";
    let title = `FocusMaster: Active (${config.profile})`;

    if (config.profile === "aggressive" && config.workerTimers) {
      text = "MAX";
      color = "#ff9100";
      icon = "icons/icon-warning-32.png";
      title = `FocusMaster: Aggressive Mode`;
    }

    chrome.action.setBadgeText({ text, tabId });
    chrome.action.setBadgeBackgroundColor({ color, tabId });
    chrome.action.setTitle({ title, tabId });
    chrome.action.setIcon({ path: icon, tabId });
  }
}

// Clean up session state on tab close
chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.session.remove(`tab_${tabId}`);
});