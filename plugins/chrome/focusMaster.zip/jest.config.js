module.exports = {
  testEnvironment: "jsdom",
  clearMocks: true,
  roots: ["<rootDir>/tests"],
  setupFilesAfterEnv: ["<rootDir>/tests/setup.js"],
};
