// popup/popup.js
document.addEventListener('DOMContentLoaded', async () => {
  const hostnameEl = document.getElementById('hostname');
  const toggleBtn = document.getElementById('toggleBtn');
  const customAmountInput = document.getElementById('customAmount');
  const saveAmountBtn = document.getElementById('saveAmountBtn');

  // Get current active tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || tab.url.startsWith('chrome://')) {
    hostnameEl.textContent = 'Not available here';
    toggleBtn.disabled = true;
    return;
  }

  const url = new URL(tab.url);
  let hostname = url.hostname;
  if (tab.url.startsWith('file://')) {
    hostname = 'file://';
  }
  hostnameEl.textContent = hostname === 'file://' ? 'Local File' : hostname;

  // Load current settings
  const { enabledSites = [] } = await chrome.storage.sync.get('enabledSites');
  const { customAmount = 100 } = await chrome.storage.sync.get('customAmount');
  
  customAmountInput.value = customAmount;
  
  let isEnabled = enabledSites.includes(hostname);
  updateButtonState();

  // Toggle functionality
  toggleBtn.addEventListener('click', async () => {
    let { enabledSites = [] } = await chrome.storage.sync.get('enabledSites');
    
    if (isEnabled) {
      enabledSites = enabledSites.filter(site => site !== hostname);
    } else {
      if (!enabledSites.includes(hostname)) {
        enabledSites.push(hostname);
      }
    }
    
    await chrome.storage.sync.set({ enabledSites });
    isEnabled = !isEnabled;
    updateButtonState();
  });

  // Save custom amount
  saveAmountBtn.addEventListener('click', async () => {
    let val = parseInt(customAmountInput.value, 10);
    if (isNaN(val) || val < 1) val = 100;
    await chrome.storage.sync.set({ customAmount: val });
    saveAmountBtn.textContent = 'Saved!';
    setTimeout(() => { saveAmountBtn.textContent = 'Save'; }, 1500);
  });

  function updateButtonState() {
    if (isEnabled) {
      toggleBtn.textContent = 'Disable on this site';
      toggleBtn.className = 'btn active';
    } else {
      toggleBtn.textContent = 'Enable on this site';
      toggleBtn.className = 'btn disabled';
    }
  }
});
